DO $$
DECLARE
  cols text[];
  vals text[];
BEGIN

  IF to_regclass('public.page_visits') IS NOT NULL THEN
    SELECT array_agg(col ORDER BY ord) INTO cols
    FROM unnest(ARRAY['id', 'created_at', 'visitor_id', 'session_id', 'user_id', 'customer_id', 'rep_id', 'page_type', 'page_key', 'page_title', 'path', 'referrer', 'metadata', 'signal_type']) WITH ORDINALITY AS t(col, ord)
    WHERE EXISTS (
      SELECT 1
      FROM information_schema.columns c
      WHERE c.table_schema = 'public'
        AND c.table_name = 'page_visits'
        AND c.column_name = t.col
    );

    IF cols IS NOT NULL AND array_length(cols, 1) > 0 THEN
      vals := ARRAY(
        SELECT CASE col
        WHEN 'id' THEN quote_literal(gen_random_uuid()::text)
        WHEN 'created_at' THEN quote_literal(now())
        WHEN 'visitor_id' THEN quote_literal('seed-visitor')
        WHEN 'session_id' THEN quote_literal('seed-session')
        WHEN 'user_id' THEN 'NULL'
        WHEN 'customer_id' THEN quote_literal('fe369ac0-9f63-4774-9a72-8732e28c6d79')
        WHEN 'rep_id' THEN quote_literal('00e37d53-bcf9-437c-9911-869fbe8d4b55')
        WHEN 'page_type' THEN quote_literal('home')
        WHEN 'page_key' THEN quote_literal('home')
        WHEN 'page_title' THEN quote_literal('الصفحة الرئيسية')
        WHEN 'path' THEN quote_literal('#home')
        WHEN 'referrer' THEN quote_literal('direct')
        WHEN 'metadata' THEN quote_literal('{"seed":true,"section":"home"}')
        WHEN 'signal_type' THEN quote_literal('view')
          ELSE 'NULL'
        END
        FROM unnest(cols) AS col
      );

      EXECUTE format(
        'INSERT INTO public.page_visits (%s) VALUES (%s)',
        array_to_string(cols, ', '),
        array_to_string(vals, ', ')
      );
    END IF;
  END IF;


  IF to_regclass('public.cart_events') IS NOT NULL THEN
    SELECT array_agg(col ORDER BY ord) INTO cols
    FROM unnest(ARRAY['id', 'created_at', 'visitor_id', 'session_id', 'user_id', 'customer_id', 'rep_id', 'event_type', 'action', 'product_id', 'product_title', 'company_id', 'unit', 'qty', 'price', 'cart_total', 'source', 'metadata']) WITH ORDINALITY AS t(col, ord)
    WHERE EXISTS (
      SELECT 1
      FROM information_schema.columns c
      WHERE c.table_schema = 'public'
        AND c.table_name = 'cart_events'
        AND c.column_name = t.col
    );

    IF cols IS NOT NULL AND array_length(cols, 1) > 0 THEN
      vals := ARRAY(
        SELECT CASE col
        WHEN 'id' THEN quote_literal(gen_random_uuid()::text)
        WHEN 'created_at' THEN quote_literal(now())
        WHEN 'visitor_id' THEN quote_literal('seed-visitor')
        WHEN 'session_id' THEN quote_literal('seed-session')
        WHEN 'user_id' THEN 'NULL'
        WHEN 'customer_id' THEN quote_literal('fe369ac0-9f63-4774-9a72-8732e28c6d79')
        WHEN 'rep_id' THEN quote_literal('00e37d53-bcf9-437c-9911-869fbe8d4b55')
        WHEN 'event_type' THEN quote_literal('ADD')
        WHEN 'action' THEN quote_literal('ADD')
        WHEN 'product_id' THEN quote_literal('1472')
        WHEN 'product_title' THEN quote_literal('منتج تجريبي')
        WHEN 'company_id' THEN quote_literal('1')
        WHEN 'unit' THEN quote_literal('pack')
        WHEN 'qty' THEN quote_literal('1')
        WHEN 'price' THEN quote_literal('0')
        WHEN 'cart_total' THEN quote_literal('0')
        WHEN 'source' THEN quote_literal('seed')
        WHEN 'metadata' THEN quote_literal('{"seed":true}')
          ELSE 'NULL'
        END
        FROM unnest(cols) AS col
      );

      EXECUTE format(
        'INSERT INTO public.cart_events (%s) VALUES (%s)',
        array_to_string(cols, ', '),
        array_to_string(vals, ', ')
      );
    END IF;
  END IF;


  IF to_regclass('public.purchase_events') IS NOT NULL THEN
    SELECT array_agg(col ORDER BY ord) INTO cols
    FROM unnest(ARRAY['id', 'created_at', 'visitor_id', 'session_id', 'user_id', 'customer_id', 'rep_id', 'order_id', 'order_number', 'invoice_number', 'customer_type', 'tier_name', 'total_amount', 'item_count', 'source']) WITH ORDINALITY AS t(col, ord)
    WHERE EXISTS (
      SELECT 1
      FROM information_schema.columns c
      WHERE c.table_schema = 'public'
        AND c.table_name = 'purchase_events'
        AND c.column_name = t.col
    );

    IF cols IS NOT NULL AND array_length(cols, 1) > 0 THEN
      vals := ARRAY(
        SELECT CASE col
        WHEN 'id' THEN quote_literal(gen_random_uuid()::text)
        WHEN 'created_at' THEN quote_literal(now())
        WHEN 'visitor_id' THEN quote_literal('seed-visitor')
        WHEN 'session_id' THEN quote_literal('seed-session')
        WHEN 'user_id' THEN 'NULL'
        WHEN 'customer_id' THEN quote_literal('fe369ac0-9f63-4774-9a72-8732e28c6d79')
        WHEN 'rep_id' THEN 'NULL'
        WHEN 'order_id' THEN quote_literal('d130e211-1c57-4218-a6b3-20bf11f6bf68')
        WHEN 'order_number' THEN quote_literal('20003')
        WHEN 'invoice_number' THEN quote_literal('20003')
        WHEN 'customer_type' THEN quote_literal('customer')
        WHEN 'tier_name' THEN quote_literal('base')
        WHEN 'total_amount' THEN quote_literal('0')
        WHEN 'item_count' THEN quote_literal('0')
        WHEN 'source' THEN quote_literal('seed')
          ELSE 'NULL'
        END
        FROM unnest(cols) AS col
      );

      EXECUTE format(
        'INSERT INTO public.purchase_events (%s) VALUES (%s)',
        array_to_string(cols, ', '),
        array_to_string(vals, ', ')
      );
    END IF;
  END IF;


  IF to_regclass('public.recommendation_signals') IS NOT NULL THEN
    SELECT array_agg(col ORDER BY ord) INTO cols
    FROM unnest(ARRAY['id', 'created_at', 'visitor_id', 'session_id', 'user_id', 'customer_id', 'rep_id', 'source', 'entity_type', 'entity_id', 'signal_type', 'weight', 'metadata']) WITH ORDINALITY AS t(col, ord)
    WHERE EXISTS (
      SELECT 1
      FROM information_schema.columns c
      WHERE c.table_schema = 'public'
        AND c.table_name = 'recommendation_signals'
        AND c.column_name = t.col
    );

    IF cols IS NOT NULL AND array_length(cols, 1) > 0 THEN
      vals := ARRAY(
        SELECT CASE col
        WHEN 'id' THEN quote_literal(gen_random_uuid()::text)
        WHEN 'created_at' THEN quote_literal(now())
        WHEN 'visitor_id' THEN quote_literal('seed-visitor')
        WHEN 'session_id' THEN quote_literal('seed-session')
        WHEN 'user_id' THEN 'NULL'
        WHEN 'customer_id' THEN quote_literal('fe369ac0-9f63-4774-9a72-8732e28c6d79')
        WHEN 'rep_id' THEN quote_literal('00e37d53-bcf9-437c-9911-869fbe8d4b55')
        WHEN 'source' THEN quote_literal('seed')
        WHEN 'entity_type' THEN quote_literal('product')
        WHEN 'entity_id' THEN quote_literal('1472')
        WHEN 'signal_type' THEN quote_literal('view')
        WHEN 'weight' THEN quote_literal('1')
        WHEN 'metadata' THEN quote_literal('{"seed":true}')
          ELSE 'NULL'
        END
        FROM unnest(cols) AS col
      );

      EXECUTE format(
        'INSERT INTO public.recommendation_signals (%s) VALUES (%s)',
        array_to_string(cols, ', '),
        array_to_string(vals, ', ')
      );
    END IF;
  END IF;

END $$;
